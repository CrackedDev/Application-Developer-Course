# Semester3

School work and Projects for Semester 3

Notes:

npm init = creates new project
