// Node.js common core global modules
const fs = require('fs');
const path = require('path');

const crc32 = require('crc/crc32');
//const { format } = require('date-fns/format');
//import { format } from 'date-fns';

function addDays(date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}

var tokenCount = function() {
    if(DEBUG) console.log('token.tokenCount()');
    return new Promise(function(resolve, reject) {
        fs.readFile(__dirname + '/tokens.json', 'utf-8', (error, data) => {
            if(error)  
                reject(error); 
            else {
                let tokens = JSON.parse(data);
                let count = Object.keys(tokens).length;
                console.log(`Current token count is ${count}.`);
                resolve(count);
            };
        });
    });
};

function newToken(username) {
    if(DEBUG) console.log('token.newToken()');

    let newToken = JSON.parse(`{
        "created": "1969-01-31 12:30:00",
        "username": "username",
        "email": "user@example.com",
        "phone": "5556597890",
        "token": "token",
        "expires": "1969-02-03 12:30:00",
        "confirmed": "tbd"
    }`);

    if(DEBUG) console.log('JSON.parse()');

    let now = new Date();
    let expires = addDays(now, 3);

    newToken.created = now;
    newToken.username = username;
    newToken.token = crc32(username).toString(16);
    newToken.expires = expires;

    fs.readFile(__dirname + '/tokens.json', 'utf-8', (error, data) => {
        if(error) throw error; 
        let tokens = JSON.parse(data);
        
        tokens.push(newToken);
        userTokens = JSON.stringify(tokens);
    
        fs.writeFile(__dirname + '/tokens.json', userTokens, (err) => {
            if (err) console.log(err);
            else { 
                console.log(`New token ${newToken.token} was created for ${username}.`);
            //    myEmitter.emit('log', 'token.newToken()', 'INFO', `New token ${newToken.token} was created for ${username}.`);
            }
        })
        
    });
    return newToken.token;
}
function tokenApp() {
    const myArgs = process.argv.slice(2);
    if(DEBUG) console.log(myArgs);
    //Use this line of code to send the 3rd and beyond args to the console 
    //if(myArgs.length > 1) console.log('the init.args: ', myArgs);
        switch (myArgs[1]) {
            case '--count':
                tokenCount();
                if(DEBUG) console.log('tokenApp.tokenCount() --count');
                break;
            case '--new':
                newToken(myArgs[2]);
                if(DEBUG) console.log('tokenApp.New() --new');
                break;
            case '--add':
                if(DEBUG) console.log('tokenApp.Add() --add');
                break;
            case '--search':
                if(DEBUG) console.log('tokenApp.Search() --search');
                break;
            default:
                if(DEBUG) console.log('tokenApp - default');
                fs.readFile(__dirname + "/views/token.txt", (error, data) => {
                    if(error) throw error;
                    console.log(data.toString());
                });
        }
    }
    
module.exports = {
    tokenApp,
  }