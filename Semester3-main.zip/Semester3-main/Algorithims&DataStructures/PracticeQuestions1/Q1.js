//Write a JavaScript function to check whether an `input` is an array or not.

function is_array(inputValue) {
  if (toString.call(inputValue) === "[object Array]") {
    return true;
  }
  return false;
}

console.log(is_array("test function"));
