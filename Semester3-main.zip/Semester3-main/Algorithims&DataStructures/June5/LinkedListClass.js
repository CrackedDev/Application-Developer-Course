class Node {
  constructor(element) {
    this.element = element;
    this.next = undefined;
  }
}
class LinkedList {
  constructor(equalsFn = this.defaultEquals) {
    this.count = 0;
    this.head = undefined;
    this.equalsFn = equalsFn;
  }
  defaultEquals(a, b) {
    return a === b;
  }
  insertFirst(element) {
    const node = new Node(element);
    let current;
    if (this.head == null) {
      this.head = node;
    } else {
      current = this.head;
      while (current.next != null) {
        current = current.next;
      }
      current.next = node;
    }
    this.count++;
  }
  insertAt(element, index) {
    if (index >= 0 && index <= this.count) {
      const node = new Node(element);
      if (index === 0) {
        const current = this.head;
        node.next;
      }
    }
  }
}
