class Node {
  constructor(init = 0) {
    this.value = init;
    this.prev = null;
    this.next = null;
  }
}
var head;
head = null;
listValues(-8);
listValues(2);
listValues(3);
listValues(4);
listValues(5);
var X = 1;

function listValues(value) {
  var temp = new Node();
  temp.value = value;
  temp.next = temp.prev = null;

  if (head == null) {
    head = temp;
  } else {
    temp.next = head;
    head.prev = temp;
    head = temp;
  }
}

function sumOfThreeNodes(X) {
  var first = head;
  var second = head.next;
  var tail = head;

  while (tail.next != null) {
    tail = tail.next;
  }

  var diff = Number.MAX_VALUE;
  var third = tail;

  while (first != null) {
    second = first.next;
    third = tail;

    while (second != null && third != null && third != second) {
      var sum = first.value + second.value + third.value;

      if (Math.abs(X - sum) < Math.abs(X - diff)) {
        diff = sum;
      }

      if (sum < X) {
        second = second.next;
      } else {
        third = third.prev;
      }
    }

    first = first.next;
  }

  console.log(diff);
}

sumOfThreeNodes(X);
