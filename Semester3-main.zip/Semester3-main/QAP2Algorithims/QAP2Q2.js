class Node {
  constructor(value) {
    this.data = value;
    this.next = null;
  }
}

let occurance = 0;

function push(head, new_data) {
  let new_node = new Node(new_data);

  new_node.next = head;

  head = new_node;

  return head;
}

function count(head, input) {
  if (head == null) return occurance;
  if (head.data == input) occurance++;

  return count(head.next, input);
}

let head = null;

head = push(head, 1);
head = push(head, 2);
head = push(head, 1);
head = push(head, 2);
head = push(head, 1);
head = push(head, 3);
head = push(head, 1);

console.log("count of 1 is " + count(head, 1));
