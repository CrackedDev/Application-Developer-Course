2; //Write a javascript function which takes in a number and an exponent as inputs and then compute the power of that number using RECURSION. Eg 2^3 = 8.

function pow(x, n) {
  if (n == 1) {
    return x;
  } else {
    return x * pow(x, n - 1);
  }
}

console.log(pow(2, 3));
