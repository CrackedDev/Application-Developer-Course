//3.	Write a javascript function which converts a decimal number to binary number using recursion.

const d2b = (num) => {
  if (num >= 1) {
    if (num % 2) {
      return d2b((num - 1) / 2) + 1;
    } else {
      return d2b(num / 2) + 0;
    }
  } else {
    return "";
  }
};
console.log(d2b(50));
console.log(d2b(1030));
console.log(d2b(6));
