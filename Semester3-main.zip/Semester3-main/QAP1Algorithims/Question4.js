//4.	Write a javascript function that computes the sum of digits of a positive integer. Eg 34 = 3+4=7; 57= 5+ 7 = 12.

function sumDigits(x) {
  x = x.toString();
  return x.length === 0 ? 0 : +x[0] + sumDigits(x.slice(1));
}

console.log(sumDigits(1234));
