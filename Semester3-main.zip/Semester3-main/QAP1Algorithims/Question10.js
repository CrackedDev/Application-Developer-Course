//There are two arrays with individual values, write a JavaScript program to compute the sum of each individual index value from the given arrays.
//Sample array:
//array1 = [1,0,2,3,4];array2 = [3,5,6,7,8,13];
//Expected Output :[4, 5, 8, 10, 12, 13]

function Arrays_sum(array1, array2) {
  var sumarray = [];
  var i = 0;
  var x = 0;

  if (array1.length === 0) return "Must Enter an array!!";
  if (array2.length === 0) return "Must Enter an array!!";

  while (i < array1.length && i < array2.length) {
    sumarray.push(array1[i] + array2[i]);
    i++;
  }

  if (i === array1.length) {
    for (x = i; x < array2.length; x++) {
      sumarray.push(array2[x]);
    }
  } else {
    for (x = i; x < array1.length; x++) {
      sumarray.push(array1[x]);
    }
  }
  return sumarray;
}

console.log(Arrays_sum([1, 0, 2, 3, 4], [3, 5, 6, 7, 8, 13]));
