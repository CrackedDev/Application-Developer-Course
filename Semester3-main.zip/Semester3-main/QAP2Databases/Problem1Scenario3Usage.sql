-- Table: public.Usage

-- DROP TABLE IF EXISTS public."Usage";

CREATE TABLE IF NOT EXISTS public."Usage"
(
    "pubID" character varying[] COLLATE pg_catalog."default" NOT NULL,
    "MonthID" character varying[] COLLATE pg_catalog."default" NOT NULL,
    "Usage" integer NOT NULL,
    "lastRev" date NOT NULL,
    CONSTRAINT "Usage_pkey" PRIMARY KEY ("pubID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Usage"
    OWNER to postgres;