-- Table: public.Classes

-- DROP TABLE IF EXISTS public."Classes";

CREATE TABLE IF NOT EXISTS public."Classes"
(
    "CourseID" character varying COLLATE pg_catalog."default" NOT NULL,
    "courseName" character varying COLLATE pg_catalog."default" NOT NULL,
    "Professor" character varying COLLATE pg_catalog."default",
    "Room" character varying COLLATE pg_catalog."default",
    CONSTRAINT "Classes_pkey" PRIMARY KEY ("CourseID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Classes"
    OWNER to postgres;