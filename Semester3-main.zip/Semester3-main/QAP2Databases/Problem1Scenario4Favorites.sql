-- Table: public.Favorites

-- DROP TABLE IF EXISTS public."Favorites";

CREATE TABLE IF NOT EXISTS public."Favorites"
(
    "UserID" character varying COLLATE pg_catalog."default" NOT NULL,
    "GenreID" character varying COLLATE pg_catalog."default",
    "AuthorID" character varying COLLATE pg_catalog."default",
    CONSTRAINT "Favorites_pkey" PRIMARY KEY ("UserID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Favorites"
    OWNER to postgres;