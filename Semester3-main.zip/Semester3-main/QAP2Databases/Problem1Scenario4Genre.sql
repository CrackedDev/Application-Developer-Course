-- Table: public.Genre

-- DROP TABLE IF EXISTS public."Genre";

CREATE TABLE IF NOT EXISTS public."Genre"
(
    "GenreID" character varying COLLATE pg_catalog."default" NOT NULL,
    "Genre" character varying COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Genre_pkey" PRIMARY KEY ("GenreID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Genre"
    OWNER to postgres;