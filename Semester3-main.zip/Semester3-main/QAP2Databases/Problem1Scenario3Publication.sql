-- Table: public.Months

-- DROP TABLE IF EXISTS public."Months";

CREATE TABLE IF NOT EXISTS public."Months"
(
    "MonthID" character varying COLLATE pg_catalog."default" NOT NULL,
    "MonthName" character varying[] COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Months_pkey" PRIMARY KEY ("MonthID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Months"
    OWNER to postgres;