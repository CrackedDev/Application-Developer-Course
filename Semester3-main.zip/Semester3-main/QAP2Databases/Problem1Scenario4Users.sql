-- Table: public.Users

-- DROP TABLE IF EXISTS public."Users";

CREATE TABLE IF NOT EXISTS public."Users"
(
    "Username" character varying COLLATE pg_catalog."default" NOT NULL,
    "homeEmail" character varying COLLATE pg_catalog."default",
    "workEmail" character varying COLLATE pg_catalog."default",
    "schoolEmail" character varying COLLATE pg_catalog."default",
    CONSTRAINT "Users_pkey" PRIMARY KEY ("Username")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Users"
    OWNER to postgres;