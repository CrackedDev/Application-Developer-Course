-- Table: public.Publication

-- DROP TABLE IF EXISTS public."Publication";

CREATE TABLE IF NOT EXISTS public."Publication"
(
    "pubID" character varying[] COLLATE pg_catalog."default" NOT NULL,
    "pubTitle" character varying[] COLLATE pg_catalog."default" NOT NULL,
    "lastRev" date NOT NULL,
    CONSTRAINT "Publication_pkey" PRIMARY KEY ("pubID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Publication"
    OWNER to postgres;