-- Table: public.Students

-- DROP TABLE IF EXISTS public."Students";

CREATE TABLE IF NOT EXISTS public."Students"
(
    "StudentID" character varying COLLATE pg_catalog."default" NOT NULL,
    "firstName" character varying COLLATE pg_catalog."default" NOT NULL,
    "lastName" character varying COLLATE pg_catalog."default" NOT NULL,
    "schoolEmail" character varying COLLATE pg_catalog."default" NOT NULL,
    "CourseID" character varying COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Students_pkey" PRIMARY KEY ("StudentID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Students"
    OWNER to postgres;