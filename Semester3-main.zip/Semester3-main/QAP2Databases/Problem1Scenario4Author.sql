-- Table: public.Author

-- DROP TABLE IF EXISTS public."Author";

CREATE TABLE IF NOT EXISTS public."Author"
(
    "AuthorID" character varying COLLATE pg_catalog."default" NOT NULL,
    "AuthorName" character varying COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Author_pkey" PRIMARY KEY ("AuthorID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Author"
    OWNER to postgres;