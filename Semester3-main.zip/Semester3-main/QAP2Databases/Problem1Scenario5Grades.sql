-- Table: public.Grades

-- DROP TABLE IF EXISTS public."Grades";

CREATE TABLE IF NOT EXISTS public."Grades"
(
    "StudentID" character varying COLLATE pg_catalog."default" NOT NULL,
    "CourseID" character varying COLLATE pg_catalog."default" NOT NULL,
    "Grade" integer NOT NULL,
    CONSTRAINT "Grades_pkey" PRIMARY KEY ("StudentID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Grades"
    OWNER to postgres;