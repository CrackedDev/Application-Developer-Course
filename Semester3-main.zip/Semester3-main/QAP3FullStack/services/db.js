const Pool = require("pg").Pool;

const pool = new Pool({
  user: "test",
  host: "localhost",
  database: "dvdrental",
  password: "keyin",
  port: 5432,
});

module.exports = pool;
