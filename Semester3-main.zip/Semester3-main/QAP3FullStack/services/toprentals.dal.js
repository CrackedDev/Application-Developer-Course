const dal = require("./db");

var toprentals = function () {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_top10bystore LIMIT 10";
    dal.query(sql, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};

var gettopstoreId = function (id) {
  return new Promise(function (resolve, reject) {
    const sql = `SELECT * FROM vw_top10bystore WHERE store = ${id} LIMIT 10`;
    dal.query(sql, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
module.exports = {
  toprentals,
  gettopstoreId,
};
