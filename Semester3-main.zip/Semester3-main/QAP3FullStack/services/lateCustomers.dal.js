const dal = require("./db");

var getLateFilms = function () {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM managerview";
    dal.query(sql, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};

var getstoreId = function (id) {
  return new Promise(function (resolve, reject) {
    const sql = `SELECT * FROM managerview WHERE store_id = ${id}`;
    dal.query(sql, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
module.exports = {
  getLateFilms,
  getstoreId,
};
