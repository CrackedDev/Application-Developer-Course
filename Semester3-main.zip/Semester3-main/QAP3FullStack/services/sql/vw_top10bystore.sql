SELECT f.title as movie, st.store_id as store, SUM(p.amount) as total_rentals from store st
JOIN staff s using (store_id)
JOIN payment p using (staff_id)
JOIN rental r using (rental_id)
JOIN inventory i using (inventory_id)
JOIN film f using (film_id)
GROUP BY movie, store
ORDER BY total_rentals DESC