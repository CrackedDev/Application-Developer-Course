 SELECT rental.rental_id,
    customer.customer_id,
    customer.first_name,
    customer.last_name,
    film.title,
    rental.rental_date,
    customer.store_id
   FROM customer
     JOIN rental ON customer.customer_id = rental.customer_id
     JOIN inventory ON rental.inventory_id = inventory.inventory_id
     JOIN film ON inventory.film_id = film.film_id
  WHERE rental.return_date IS NULL
  ORDER BY customer.store_id;