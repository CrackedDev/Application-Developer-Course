const express = require("express");
const router = express.Router();
router.use(express.static("public"));

const topfilmsDal = require("../services/toprentals.dal");

router.get("/:id", async (req, res) => {
  let toprentals = await topfilmsDal.gettopstoreId(req.params.id);

  res.render("toprentals.ejs", { toprentals });
});

module.exports = router;
