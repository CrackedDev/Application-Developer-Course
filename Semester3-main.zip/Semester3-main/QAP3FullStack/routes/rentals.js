const express = require("express");
const router = express.Router();
router.use(express.static("public"));

const latefilmsDal = require("../services/lateCustomers.dal");

router.get("/", async (req, res) => {
  let laterentals = await latefilmsDal.getLateFilms();

  res.render("laterentals.ejs", { laterentals });
});
router.get("/:id", async (req, res) => {
  let laterentals = await latefilmsDal.getstoreId(req.params.id);

  res.render("laterentals.ejs", { laterentals });
});

module.exports = router;
