const http = require("http");
const routes = require("./routes.js");
const EventEmitter = require("events");
const { Console } = require("console");
const path = require("path");

const port = 3000;

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });

  switch (req.url) {
    case "/":
      console.log("root");
      res.statusCode = 200;
      routes.routePage("./views/index.html", res);
      myEmitter.emit("index");
      firstEvent(res, req);
      firstRandom();
      break;
    case "/about":
      console.log("about");
      statusCode = 200;
      routes.routePage("./views/about.html", res);
      firstEvent(res, req);
      firstRandom();
      break;
    case "/contact":
      console.log("/contact");
      res.statusCode = 200;
      routes.routePage("./views/contact.html", res);
      firstEvent(res, req);
      firstRandom();
      break;
    case "/products":
      console.log("/products");
      res.statusCode = 200;
      routes.routePage("./views/products.html", res);
      firstEvent(res, req);
      firstRandom();
      break;
    case "/subscribe":
      console.log("/subscribe");
      res.statusCode = 200;
      routes.routePage("./views/subscribe.html", res);
      firstEvent(res, req);
      firstRandom();
      break;
    default:
      console.log("default");
      res.statusCode = 404;
      routes.routePage("./views/fourofour.html", res);
      firstEvent(res, req);
      firstRandom();
      break;
  }
});

server.listen(port, "localhost", () =>
  console.log(
    `server started on port ${port}; ` + "press Ctrl-C to terminate...."
  )
);

class MyEmitter extends EventEmitter {}
const myEmitter = new MyEmitter();

myEmitter.addListener("pageStatus", (res, req) =>
  console.log("HTTP Status Code: " + res.statusCode)
);
myEmitter.on("pageStatus", (res, req) => console.log("Route:  " + req.url));

myEmitter.on("index", () => console.log("This is the Home Page!"));

myEmitter.on("randomEvent", () => console.log("This is a random Event!"));

//Counts how many times each event fired.
console.log(
  "The 'pageStatus' event fired " +
    myEmitter.listenerCount("pageStatus") +
    "times!"
);
console.log();
console.log(
  "The 'randomEvent' event fired " +
    myEmitter.listenerCount("randomEvent") +
    "times!"
);

console.log(
  "The current events that have been bound are: " + myEmitter.eventNames()
);
//fire events! PEWPEW
console.log("\nFiring the 'pageStatus' Event!");
const firstEvent = (res, req) => {
  myEmitter.emit("pageStatus", res, req);
};

console.log("\nFiring the 'randomEvent'...um... Event!");
const firstRandom = () => {
  myEmitter.emit("randomEvent");
};
