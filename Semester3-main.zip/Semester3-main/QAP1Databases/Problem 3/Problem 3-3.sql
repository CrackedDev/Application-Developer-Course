DELETE FROM public.customer
	WHERE address_id = 43;