UPDATE public.customer
	SET address_id = 25
	WHERE last_name = 'Mario';