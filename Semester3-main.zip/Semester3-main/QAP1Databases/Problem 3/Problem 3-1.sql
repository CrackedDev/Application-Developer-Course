INSERT INTO customer (first_name, last_name, email, activebool, store_id, address_id)
VALUES 
('Mario', 'Mario', 'mario@mushroom.com', true, 2, 43), 
('Luigi', 'Mario', 'luigi@mushroom.com', true, 2, 43), 
('Peach', 'Toadstool', 'peach@mushroom.com', false, 2, 43), 
('Toad', 'Mushroom', 'toad@mushroom.com', true, 2, 43), 
('Toadette', 'Mushroom', 'toadette@mushroom.com', true, 2, 43);