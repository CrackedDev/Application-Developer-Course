SELECT title, length
FROM film
WHERE length >= 60
ORDER BY film.length