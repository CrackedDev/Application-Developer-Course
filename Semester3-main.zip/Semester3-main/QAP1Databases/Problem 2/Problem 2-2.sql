SELECT title, description, length, rating FROM film
Where length >= 60