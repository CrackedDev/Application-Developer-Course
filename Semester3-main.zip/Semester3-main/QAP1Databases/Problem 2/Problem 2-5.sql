SELECT film.title, film.length, film_actor.actor_id
FROM (film
JOIN film_actor ON film.film_id = film_actor.film_id)