SELECT COUNT(length >=60), rating
FROM film
GROUP BY rating