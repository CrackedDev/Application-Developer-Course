//used to retrieve information about the users operating system the program runs on and interact with it.

const os = require("os");
console.log("hostname: " + os.hostname());
console.log("Platform: " + os.platform());
console.log("Architecture: " + os.arch());
console.log("freemem: " + os.freemem());
console.log();
const cpu = os.cpus();
const ProcName = cpu[0];
cpu.forEach((Proc) => {
  name = Proc.model;
});

console.log("CPU: " + name);
console.log("Cores: " + cpu.length);

const user = os.userInfo();
console.log();
console.log("User: ");
console.log();
console.log("Username: " + user.username);
console.log("Home Directory: " + user.homedir);
console.log();

const netCard = os.networkInterfaces();
console.log("Network Cards:");
console.log(netCard);
