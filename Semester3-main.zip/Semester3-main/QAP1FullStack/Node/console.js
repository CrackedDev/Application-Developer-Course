//Console provides access to the debugging console.

//ouput single objects.

const textOutput = "This is an example of text output.";

console.log(textOutput);

//output multiple objects

const cat = "Griffin";
const color = "Black";
console.info("My cat's name is", cat, ". His fur is colored ", color, ".");

//styling console output

console.log(
  "This output is %cFANCYYYYYYY!!!",
  "color: yellow; font-style: italic; background-color: blue; padding: 2px"
);
console.log(
  "This is %cMy stylish message",
  "color: yellow; font-style: italic; background-color: blue;padding: 2px"
);
