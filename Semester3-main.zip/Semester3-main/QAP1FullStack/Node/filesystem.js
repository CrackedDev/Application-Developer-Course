// fs module allows access to the local file system. It allows node to read and write data to the local machine.

const fs = require("fs");

fs.writeFile(
  "filesystem.txt",
  "This is an example of file system access",
  function (err) {
    if (err) throw err;
    console.log("File is created successfully.");
  }
);

const fileName = "filesystem.txt";
fs.readFile(fileName, "utf8", (err, data) => {
  if (err) {
    console.log(err);
    return;
  }
  console.log(data);
});
