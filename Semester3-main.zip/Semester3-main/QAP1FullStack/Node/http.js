// the HTTP module is the key module used for node.js Networking. It allowes for web server functionality.

const http = require("http");

//Creating a server on port 4000 and serving a simple sentence.

const port = 4000;

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end("This is an example of a basic web page!");
});

//listening for input on specified port and displaying to user.

server.listen(port, () =>
  console.log(
    `server started on port ${port}; ` + "press Ctrl-C to terminate...."
  )
);
