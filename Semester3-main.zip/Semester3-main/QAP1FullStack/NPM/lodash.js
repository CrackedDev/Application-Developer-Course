// Lodash is used to make javascript easier with working with arrays, numbers, ogjects, strings, etc.

const lodash = require("lodash");

//Outputs first and last elements of an array:

console.log("First and Last Months:");
console.log();

const list = [
  "jan",
  "feb",
  "mar",
  "apr",
  "may",
  "jun",
  "jul",
  "aug",
  "sep",
  "oct",
  "nov",
  "dec",
];

const first = lodash.first(list);
const last = lodash.last(list);

console.log(`First element is ${first}`);
console.log(`Last Element is ${last}`);

console.log("________________________________________________________");
console.log();

//Outputs different case of words:

let words = ["sky", "Sun", "Blue Island"];

console.log(lodash.map(words, lodash.camelCase));
console.log(lodash.map(words, lodash.capitalize));
console.log(lodash.map(words, lodash.kebabCase));
console.log(lodash.map(words, lodash.lowerCase));
console.log(lodash.map(words, lodash.upperCase));
