const express = require('express');
const router = express.Router();

const { getEverything, getByFirstName, getByFullText } = require('../services/search.dal')

router.post('/', async (req, res) => {
// let results = await getEverything();
// let results = await getByFirstName(req.body.search_term);
let results = await getByFullText(req.body.search_term);

//   console.log(results);
// array with mock data for testing and UI development
/*
    const results = [
        {
            "first_name": "Flynn",
            "last_name": "Von Brook",
            "children": [
                {
                    "gender": "Male",
                    "name": "Lindsey",
                    "birth": "2/21/1998",
                    "animal": "Dolphin, striped"
                },
                {
                    "gender": "Female",
                    "name": "Savina",
                    "birth": "4/23/1996",
                    "animal": "Steenbuck"
                },
                {
                    "gender": "Female",
                    "name": "Audra",
                    "birth": "3/2/2003",
                    "animal": "Porcupine, indian"
                },
                {
                    "gender": "Male",
                    "name": "Meredith",
                    "birth": "12/13/2001",
                    "animal": "Dragon, asian water"
                },
                {
                    "gender": "Female",
                    "name": "Godiva",
                    "birth": "8/23/1997",
                    "animal": "Falcon, peregrine"
                }
            ],
            "phrase": "Programmable encompassing orchestration",
            "story": "University of Sulaimania (Kurdistan Region)"
        }, {
            "first_name": "Rolf",
            "last_name": "Oakton",
            "children": [
                {
                    "gender": "Female",
                    "name": "Ariana",
                    "birth": "9/25/1999",
                    "animal": "North American red fox"
                },
                {
                    "gender": "Genderqueer",
                    "name": "Syman",
                    "birth": "11/18/2005",
                    "animal": "Stork, black-necked"
                },
                {
                    "gender": "Female",
                    "name": "Tandie",
                    "birth": "11/22/2006",
                    "animal": "Magpie, australian"
                },
                {
                    "gender": "Male",
                    "name": "Clarence",
                    "birth": "4/7/2003",
                    "animal": "Wild boar"
                }
            ],
            "phrase": "Grass-roots non-volatile groupware",
            "story": "Shanghai Television University"
        }
    ];
*/
    // if (results.length > 0) {
    //     results.forEach(parent => {
    //         console.log();
    //         console.log('FAMILY');
    //         console.log(parent.first_name + ' ' + parent.last_name + '\n' + parent.phrase + '\n' + parent.story);
    //         console.log('CHILDREN');
    //         parent.children.forEach(child => {
    //             console.log(child.name + ' ' + child.gender + ' ' + child.birth + ' ' + child.animal);
    //         })
    //     }) 
    // }
        res.render('search',{results});
});

module.exports = router;