const { MongoClient } = require('mongodb');
const uri = "mongodb://localhost:27017/";
const client = new MongoClient(uri);

async function getEverything() {
    await client.connect();
    const cursor = client.db("Search").collection("family").find();
    const results = await cursor.toArray();

    // if (results.length > 0) {
    //     console.log(`Found the families`);
    //     results.forEach((results, i) => {
    //         console.log();
    //         console.log(`Family Name: ${results.last_name}`);
    //         console.log(`     story: ${results.story}`);
    //     });
    // } else {
    //     console.log(`No families found'`);
    // }
    return results;
}
async function getByFirstName(name) {
    await client.connect();
    const cursor = client.db("Search").collection("family").find({first_name: name});
    const results = await cursor.toArray();

    return results;
}

async function getByFullText(text) {
    await client.connect();
    const cursor = client.db("Search").collection("family").find({$text: {$search: text}});
    const results = await cursor.toArray();

    return results;
}

module.exports = {
    getEverything,
    getByFirstName,
    getByFullText,
  }