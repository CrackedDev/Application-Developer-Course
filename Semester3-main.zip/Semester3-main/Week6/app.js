/*************************
 * File Name: app.js
 * Purpose: The main routines to start the initialization app
 * 
 * Commands:
app init all          creates the folder structure and config file
app init mk           creates the folder structure
app init cat          creates the config file with default settings
 *
 * Created Date: 09 Jan 2022
 * Authors:
 * PJR - Peter Rawsthorne
 * FF - Fred Flinstone
 * Revisions:
 * Date, Author, Description
 * 09 Jan 2022, PJR, File created
 * 16 Feb 2022, FF, enhanced..
 * 08 June 2022, PJR, fix bugs, enhance
 *
 *************************/
global.DEBUG = true;
const fs = require("fs");
const { initializeApp } = require('./init.js');
const { configApp } = require('./config.js');

const myArgs = process.argv.slice(2);
if(DEBUG) if(myArgs.length > 1) console.log('the myapp.args: ', myArgs);

switch (myArgs[0]) {
    case 'init':
    case 'i':
        if(DEBUG) console.log(myArgs[0], ' - initialize the app.');
        initializeApp();
        break;
    case 'config':
    case 'c':
        if(DEBUG) console.log(myArgs[0], ' - display the configuration file');
        configApp();
        break;
    case 'token':
    case 't':
        if(DEBUG) console.log(myArgs[0], ' - generate a user token');
        //tokenApp();
        break;  
    case 'help':
    case 'h':
    default:
        fs.readFile(__dirname + "/usage.txt", (error, data) => {
            if(error) throw error;
            console.log(data.toString());
        });
}

