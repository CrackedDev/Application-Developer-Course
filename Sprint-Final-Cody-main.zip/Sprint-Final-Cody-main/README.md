This repository contains my submission for Semester 1 at Keyin College Application Development program: Introduction to Python.
The project is part 1 of a Sprint Week assignment meant as a final assessment.
