package com.qap1SDAT;

public class WordFinder {

    public boolean findWordInSentence(String findWord, String charSequence) {
        return charSequence.contains(findWord);
    }

}
