package com.general;

import java.util.Date;

public interface DateValidator {

    boolean isValid(String dateString);

    int dateCheck();
}
