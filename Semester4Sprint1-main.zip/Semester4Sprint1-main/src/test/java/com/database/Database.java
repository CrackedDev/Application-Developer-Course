package com.database;

public class Database {
}
