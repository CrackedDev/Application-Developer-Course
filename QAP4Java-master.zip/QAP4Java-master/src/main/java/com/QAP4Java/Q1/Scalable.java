package com.QAP4Java.Q1;

public interface Scalable {
    void scaleUp(double inc);
    void scaleDn(double dec);


}
