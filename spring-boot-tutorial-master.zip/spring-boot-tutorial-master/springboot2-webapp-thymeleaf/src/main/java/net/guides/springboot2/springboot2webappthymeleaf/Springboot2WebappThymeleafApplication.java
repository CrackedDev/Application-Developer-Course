package net.guides.springboot2.springboot2webappthymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2WebappThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot2WebappThymeleafApplication.class, args);
	}
}
